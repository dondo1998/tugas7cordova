<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id8174847_admin","admin123","id8174847_akademik") or die ("could not connect database");
?>
